import 'package:flutter/material.dart';
import 'package:pen_pal_magic_app/backendfuncs.dart';
import 'package:pen_pal_magic_app/search_screen.dart';
import 'package:pen_pal_magic_app/three_screens.dart';

import 'letters_screen.dart';

class UserProfile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Color.fromRGBO(2, 71, 145, 100),
        body: Padding(
          padding: EdgeInsets.all(3.0),
          child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              child: Column(children: <Widget>[
                SizedBox(
                    height: size.height / 10,
                    width: size.width / 1,
                    child: const Text('Your Profile',
                        textAlign: TextAlign.center,
                        textScaleFactor: 2,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 30,
                            fontWeight: FontWeight.bold))),
                SizedBox(
                    height: size.height / 16,
                    width: size.width / 1,
                    child: const Text('Name : Rithvik',
                        textAlign: TextAlign.left,
                        textScaleFactor: 2,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold))),
                SizedBox(
                    height: size.height / 16,
                    width: size.width / 1,
                    child: const Text('Age: 15',
                        textAlign: TextAlign.left,
                        textScaleFactor: 2,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold))),
                SizedBox(
                    height: size.height / 16,
                    width: size.width / 1,
                    child: const Text('Country: India',
                        textAlign: TextAlign.left,
                        textScaleFactor: 2,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold))),
                SizedBox(
                    height: size.height / 16,
                    width: size.width / 1,
                    child: const Text('Language: English,Hindi,Telugu',
                        textAlign: TextAlign.left,
                        textScaleFactor: 2,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold))),
                SizedBox(
                    height: size.height / 16,
                    width: size.width / 1,
                    child: const Text('About Me :',
                        textAlign: TextAlign.left,
                        textScaleFactor: 2,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold))),
                SizedBox(
                    height: size.height / 2.1,
                    width: size.width / 1,
                    child: const Text(
                        'I am 15 year old student at aga khan acadmey. I like to play cricket, make beats , watch some anime and play fifa. I am also an active theatre,drama actor, and participate in summer productions. I love to eat biryani, as well as seafood related dishes are my favourite. I like the color of cyan, and any neon colours. I am in the City of Hyderabad in India. ',
                        textAlign: TextAlign.left,
                        textScaleFactor: 2,
                        style: TextStyle(
                            color: Color.fromRGBO(108, 173, 39, 10),
                            fontSize: 13,
                            fontWeight: FontWeight.bold))),
                Container(
                    height: size.height / 10,
                    width: size.width,
                    alignment: Alignment.bottomCenter,
                    child: NavBar(key: UniqueKey())),
              ])),
        ));
  }
}

class NavBar extends StatefulWidget {
  const NavBar({required Key key}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => UserProfile()),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => SearchScreen()),
        );
        break;

      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ThreeScreens()),
        );
        break;
      default:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => UserProfile()),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(),
        bottomNavigationBar: Container(
            alignment: Alignment.bottomCenter,
            child: BottomNavigationBar(
              backgroundColor: const Color.fromRGBO(108, 173, 39, 100),
              currentIndex: _currentIndex,
              onTap: _onItemTapped,
              items: const [
                BottomNavigationBarItem(
                  icon: Icon(Icons.account_box_sharp,
                      color: Colors.black, size: 48),
                  label: "Profile",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.search_sharp, color: Colors.black, size: 48),
                  label: "Search",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.info, color: Colors.black, size: 48),
                  label: 'App info',
                ),
              ],
            )));
  }
}
