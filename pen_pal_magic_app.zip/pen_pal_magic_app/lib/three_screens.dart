import 'package:flutter/material.dart';
import 'package:pen_pal_magic_app/backendfuncs.dart';
import 'package:pen_pal_magic_app/donate_page.dart';
import 'package:pen_pal_magic_app/search_screen.dart';
import 'package:pen_pal_magic_app/user_profile.dart';

import 'about_page.dart';
import 'contact_page.dart';
import 'letters_screen.dart';

class ThreeScreens extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Color.fromRGBO(2, 71, 145, 100),
        body: Padding(
          padding: EdgeInsets.all(3.0),
          child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              child: Column(children: <Widget>[
                SizedBox(
                    height: size.height / 4,
                    width: size.width / 1,
                    child: const Text('App Info',
                        textAlign: TextAlign.center,
                        textScaleFactor: 2,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 30,
                            fontWeight: FontWeight.bold))),
                Padding(
                    padding: const EdgeInsets.symmetric(vertical: 45.0),
                    child: SizedBox(
                        height: size.height / 9,
                        child: GestureDetector(
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const DonatePage()),
                          ),
                          child: donateButton(size),
                        ))),
                Padding(
                    padding: const EdgeInsets.symmetric(vertical: 45.0),
                    child: SizedBox(
                        height: size.height / 9,
                        child: GestureDetector(
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ContactPage()),
                          ),
                          child: contactButton(size),
                        ))),
                Padding(
                    padding: const EdgeInsets.symmetric(vertical: 45.0),
                    child: SizedBox(
                        height: size.height / 9,
                        child: GestureDetector(
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const AboutPage()),
                          ),
                          child: aboutButton(size),
                        ))),
                Container(
                    height: size.height / 11,
                    width: size.width,
                    alignment: Alignment.bottomCenter,
                    child: NavBar(key: UniqueKey())),
              ])),
        ));
  }
}

Widget donateButton(Size size) {
  return Container(
      height: size.height / 13,
      width: size.width / 1.1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: const Color.fromRGBO(108, 173, 39, 100),
      ),
      alignment: Alignment.center,
      child: const Text("Donate",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          )));
}


Widget contactButton(Size size) {
  return Container(
      height: size.height / 13,
      width: size.width / 1.1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: const Color.fromRGBO(108, 173, 39, 100),
      ),
      alignment: Alignment.center,
      child: const Text("Contact",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          )));
}


Widget aboutButton(Size size) {
  return Container(
      height: size.height / 13,
      width: size.width / 1.1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: const Color.fromRGBO(108, 173, 39, 100),
      ),
      alignment: Alignment.center,
      child: const Text("About",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          )));
}

class NavBar extends StatefulWidget {
  const NavBar({required Key key}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => UserProfile()),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => SearchScreen()),
        );
        break;

      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ThreeScreens()),
        );
        break;
      default:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => UserProfile()),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(),
        bottomNavigationBar: Container(
            alignment: Alignment.bottomCenter,
            child: BottomNavigationBar(
              backgroundColor: const Color.fromRGBO(108, 173, 39, 100),
              currentIndex: _currentIndex,
              onTap: _onItemTapped,
              items: const [
                BottomNavigationBarItem(
                  icon: Icon(Icons.account_box_sharp,
                      color: Colors.black, size: 48),
                  label: "Profile",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.search_sharp, color: Colors.black, size: 48),
                  label: "Search",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.info, color: Colors.black, size: 48),
                  label: 'App info',
                ),
              ],
            )));
  }
}
