import 'package:flutter/material.dart';
import 'package:pen_pal_magic_app/backendfuncs.dart';
import 'package:pen_pal_magic_app/login_screen.dart';

import 'about_page.dart';
import 'contact_page.dart';
import 'donate_page.dart';

class CreateAccount extends StatefulWidget {
  const CreateAccount({Key? key}) : super(key: key);

  @override
  State<CreateAccount> createState() => _CreateAccountState();
}

class _CreateAccountState extends State<CreateAccount> {

  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  bool isLoading = false;


  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      // resizeToAvoidBottomInset: false,
      // appBar: AppBar(
      //   title: const Text('Pen Pal Magic App'),
      //   backgroundColor: const Color.fromRGBO(
      //       108, 173, 39, 100), //top bar to display app title with color config
      // ),
      backgroundColor: const Color.fromRGBO(
          2, 71, 145, 100), //background color of app declared

      body: isLoading
          ? Center(
        child: Container(
          height: size.height / 20,
          width: size.height / 20,
          child: CircularProgressIndicator(),
        ),
      )
        : SingleChildScrollView(
          child: Column(
        children: [
          Padding(
              padding: const EdgeInsets.symmetric(vertical: 23.0),
              child: SizedBox(
                height: size.height / 4,
                width: size.width,
                child: imageAss(size),
              )),
          Padding(
              padding: const EdgeInsets.symmetric(vertical: 1.0),
              child: Container(
                height: size.height / 9,
                width: size.width,
                alignment: Alignment.center,
                child: emailField(size, 'enter email', Icons.email, _email),
              )),
          Padding(
              padding: const EdgeInsets.symmetric(vertical: 1.0),
              child: Container(
                height: size.height / 8,
                width: size.width,
                alignment: Alignment.center,
                child: passwordField(size, 'enter password', Icons.lock, _password),
              )),
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 9.0),
        child: SizedBox(
          height: size.height / 12,
          child: GestureDetector(
              onTap: () {
                if (_email.text.isNotEmpty &&
                    _password.text.isNotEmpty) {
                  setState(() {
                    isLoading = true;
                  });

                  createAccount(_email.text, _password.text).then((user) {
                    if (user != null) {
                      setState(() {
                        isLoading = false;
                      });
                      Navigator.push(
                          context, MaterialPageRoute(builder: (_) => LoginScreen()));
                      print("Account Created Sucessfull");
                    } else {
                      print("Creation Failed");
                      setState(() {
                        isLoading = false;
                      });
                    }
                  });
                } else {
                  print("Please enter Fields");
                }
              },
            child: regButton(size)))),
          Container(
            height: size.height / 3,
            width: size.width,
            alignment: Alignment.bottomCenter,
            child: const NavBar(),),
    ],
      ),
        ),
    );
  }
}

Widget imageAss(Size size) {
  return SizedBox(
    height: size.height / 4,
    width: size.width / 1.1,
    child: Image.asset('assets/images/murphycharitylogo.png',
        alignment: const Alignment(0, -0.5), scale: (0.5)),
  );
}

Widget emailField(Size size, String hintText, IconData icon, TextEditingController cont) {
  return SizedBox(
    height: size.height / 4,
    width: size.width / 1.1,
    child: TextField(
      controller: cont,
      style: const TextStyle(
          fontSize: 18,
          color: Color.fromRGBO(252, 252, 252, 100),
          fontWeight: FontWeight.bold),
      decoration: const InputDecoration(
        hintText: 'Enter email',
        hintStyle:
        TextStyle(fontSize: 26, color: Color.fromRGBO(108, 173, 39, 50)),
        border: OutlineInputBorder(),
        enabledBorder: OutlineInputBorder(
          borderSide:
          BorderSide(width: 5, color: Color.fromRGBO(108, 173, 39, 100)),
        ),
        prefixIcon: Icon(
          Icons.mail,
          color: Color.fromRGBO(108, 173, 39, 100),
        ),
      ),
    ),
  );
}


Widget passwordField(Size size, String hintText, IconData icon, TextEditingController cont) {
  return SizedBox(
    height: size.height / 4,
    width: size.width / 1.1,
    child: TextField(
      controller: cont,
      style: const TextStyle(
          fontSize: 18,
          color: Color.fromRGBO(252, 252, 252, 100),
          fontWeight: FontWeight.bold),
      decoration: const InputDecoration(
        hintText: 'Enter password',
        hintStyle:
        TextStyle(fontSize: 26, color: Color.fromRGBO(108, 173, 39, 50)),
        border: OutlineInputBorder(),
        enabledBorder: OutlineInputBorder(
          borderSide:
          BorderSide(width: 5, color: Color.fromRGBO(108, 173, 39, 100)),
        ),
        prefixIcon: Icon(
          Icons.mail,
          color: Color.fromRGBO(108, 173, 39, 100),
        ),
      ),
    ),
  );
}


Widget regButton(Size size) {
  return Container(
      height: size.height / 12,
      width: size.width / 1.1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: const Color.fromRGBO(108, 173, 39, 100),
      ),
      alignment: Alignment.center,
      child: const Text("Create Account",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          )));
}


class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentIndex = 0;

  final screens = [
    const DonatePage(),
    const ContactPage(),
    const AboutPage(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (value) {
          setState(() {
            _currentIndex = value;
          });
        },
        backgroundColor: const Color.fromRGBO(108, 173, 39, 100),
        // currentIndex: _currentIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.monetization_on, color: Colors.black, size: 48),
            label: 'donate',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.phone, color: Colors.black, size: 48),
            label: "Contact",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.question_mark, color: Colors.black, size: 48),
            label: 'About',
          ),
        ],
        // onTap: (index) {
        //   setState(() {
        //     _currentIndex=index;
        //   });
        // },
      ),
    );
  }
}
