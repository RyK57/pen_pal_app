import 'package:flutter/material.dart';
// import 'package:pen_pal_magic_app/backendfuncs.dart';
// import 'package:pen_pal_magic_app/search_screen.dart';
// import 'package:pen_pal_magic_app/three_screens.dart';
// import 'package:pen_pal_magic_app/user_profile.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

class LettersScreen extends StatelessWidget {
  final Map<String, dynamic> userMap;
  final String letterBoxId;

  LettersScreen({required this.letterBoxId, required this.userMap});

  final TextEditingController _letter = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  FirebaseAuth _auth = FirebaseAuth.instance;

  void onSendLetter() async {
    if (_letter.text.isNotEmpty) {
      Map<String, dynamic> letters = {
        'sentby': _auth.currentUser!.displayName!,
        'letter': _letter.text,
        'type': 'text',
        'time': FieldValue.serverTimestamp(),
      };

      _letter.clear();
      await _firestore
          .collection('letterbox')
          .doc(letterBoxId)
          .collection('letters')
          .add(letters);
    } else {
      print("Enter Some Text");
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
        backgroundColor: Color.fromRGBO(2, 71, 145, 100),
        appBar: AppBar(
          backgroundColor: Color.fromRGBO(108, 173, 39, 100),
          title: StreamBuilder<DocumentSnapshot>(
            stream:
            _firestore.collection("users").doc(userMap['uid']).snapshots(),
            builder: (context, snapshot) {
              if (snapshot.data != null) {
                return Container(
                  child: Column(
                    children: [
                      Text(userMap['email']),
                      Text(
                        snapshot.data!['status'],
                        style: TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                );
              } else {
                return Container();
              }
            },
          ),
        ),
        body: SingleChildScrollView(
            child: Column(children: [
          Container(
              height: size.height / 1.25,
              width: size.width,
              child: StreamBuilder<QuerySnapshot>(
                  stream: _firestore
                      .collection('letterbox')
                      .doc(letterBoxId)
                      .collection('letters')
                      .orderBy('time', descending: false)
                      .snapshots(),
                  builder: (BuildContext context,
                      AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (snapshot.data != null) {
                      return ListView.builder(
                        itemCount: snapshot.data!.docs.length,
                        itemBuilder: (context, index) {
                          Map<String, dynamic> map = snapshot.data!.docs[index]
                              .data() as Map<String, dynamic>;
                          return letters(size, map);
                        },
                      );
                    } else {
                      return Container();
                    }
                  })),
          Container(
              height: size.height / 16,
              width: size.width / 0,
              alignment: Alignment.bottomLeft,
              child: Container(
                  height: size.height / 9,
                  width: size.width / 0,
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                            height: size.height / 5,
                            width: size.width / 1.6,
                            child: TextField(
                                controller: _letter,
                                style: const TextStyle(
                                    fontSize: 18,
                                    color: Color.fromRGBO(252, 252, 252, 100),
                                    fontWeight: FontWeight.bold),
                                decoration: InputDecoration(
                                  hintText: 'Send Letter',
                                  hintStyle: TextStyle(
                                      color: Color.fromRGBO(108, 173, 39, 100)),
                                  border: OutlineInputBorder(),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                        width: 5,
                                        color:
                                            Color.fromRGBO(108, 173, 39, 100)),
                                  ),
                                ))),
                        IconButton(
                            icon: Icon(Icons.send),
                            iconSize: 30,
                            color: Color.fromRGBO(108, 173, 39, 100),
                            onPressed: onSendLetter),
                        IconButton(
                            icon: Icon(Icons.attach_file),
                            iconSize: 30,
                            color: Color.fromRGBO(108, 173, 39, 100),
                            onPressed: () {}),
                        IconButton(
                            icon: Icon(Icons.camera_alt),
                            iconSize: 30,
                            color: Color.fromRGBO(108, 173, 39, 100),
                            onPressed: () {})
                      ])))
        ])));
  }
}

Widget letters(Size size, Map<String, dynamic> map) {
  FirebaseAuth _auth = FirebaseAuth.instance;
  return map['type'] == 'text'
      ?  Container(
    width: size.width,
    alignment: map['sentby'] == _auth.currentUser!.displayName!
        ? Alignment.centerRight
        : Alignment.centerLeft,
    child: Container(
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      margin: EdgeInsets.symmetric(vertical: 5, horizontal: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Color.fromRGBO(108, 173, 39, 100),
      ),
      child: Text(
        map['letter'],
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: Colors.white,
        ),
      ),
    ),
  ):
      Container();
}
