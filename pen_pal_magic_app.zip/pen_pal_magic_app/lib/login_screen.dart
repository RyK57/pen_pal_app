import 'package:flutter/material.dart';
import 'package:pen_pal_magic_app/create_account.dart';
import 'package:pen_pal_magic_app/user_profile.dart';
import 'package:pen_pal_magic_app/backendfuncs.dart';

import 'about_page.dart';
import 'contact_page.dart';
import 'donate_page.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  bool isLoading = false;


  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      // resizeToAvoidBottomInset: false,
      // appBar: AppBar(
      //   title: const Text('Pen Pal Magic App'),
      //   backgroundColor: const Color.fromRGBO(
      //       108, 173, 39, 100), //top bar to display app title with color config
      // ),
      backgroundColor: const Color.fromRGBO(
          2, 71, 145, 100), //background color of app declared

    body: isLoading
    ? Center(
    child: Container(
    height: size.height / 20,
    width: size.height / 20,
    child: CircularProgressIndicator(),
    ),
    )
        : SingleChildScrollView(
    child: Column(
        children: [
          Padding(
              padding: const EdgeInsets.symmetric(vertical: 23.0),
              child: SizedBox(
                height: size.height / 4,
                width: size.width,
                child: imageAss(size),
              )),
          Padding(
              padding: const EdgeInsets.symmetric(vertical: 0.0),
              child: Container(
                height: size.height / 7,
                width: size.width,
                alignment: Alignment.center,
                child: emailField(size, 'email', Icons.email, _email),
              )),
          Padding(
              padding: const EdgeInsets.symmetric(vertical: 1.0),
              child: Container(
                height: size.height / 6,
                width: size.width,
                alignment: Alignment.center,
                child: passwordField(size, 'password', Icons.lock, _password),
              )),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 9.0),
            child: SizedBox(
              height: size.height / 12,
              child: GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const CreateAccount()),
                ),
                child: regButton(size),
              ),
            ),
          ),
          Container(
            height: size.height / 9,
            alignment: Alignment.center,
            child: GestureDetector(
              onTap: () {
                if (_email.text.isNotEmpty && _password.text.isNotEmpty) {
                  setState(() {
                    isLoading = true;
                  });

                  logIn(_email.text, _password.text).then((user) {
                    if (user != null) {
                      print("Login Sucessfull");
                      setState(() {
                        isLoading = false;
                      });
                      Navigator.push(
                          context, MaterialPageRoute(builder: (_) => UserProfile()));
                    } else {
                      print("Login Failed");
                      setState(() {
                        isLoading = false;
                      });
                    }
                  });
                } else {
                  print("Please fill form correctly");
                }
              },
              child: logButton(size),
            ),
          ),
          Container(
              height: size.height / 6,
              width: size.width,
              alignment: Alignment.bottomCenter,
              child: NavBar(key: UniqueKey())),
        ],
      ),
    ));
  }
}

Widget imageAss(Size size) {
  return SizedBox(
    height: size.height / 4,
    width: size.width / 1.1,
    child: Image.asset('assets/images/murphycharitylogo.png',
        alignment: const Alignment(0, -0.5), scale: (0.5)),
  );
}

Widget emailField(Size size, String hintText, IconData icon, TextEditingController cont) {
  return SizedBox(
    height: size.height / 4,
    width: size.width / 1.1,
    child: TextField(
      controller: cont,
      style: const TextStyle(
          fontSize: 18,
          color: Color.fromRGBO(252, 252, 252, 100),
          fontWeight: FontWeight.bold),
      decoration: const InputDecoration(
        hintText: 'Enter email',
        hintStyle:
            TextStyle(fontSize: 26, color: Color.fromRGBO(108, 173, 39, 50)),
        border: OutlineInputBorder(),
        enabledBorder: OutlineInputBorder(
          borderSide:
              BorderSide(width: 5, color: Color.fromRGBO(108, 173, 39, 100)),
        ),
        prefixIcon: Icon(
          Icons.mail,
          color: Color.fromRGBO(108, 173, 39, 100),
        ),
      ),
    ),
  );
}


Widget passwordField(Size size, String hintText, IconData icon, TextEditingController cont) {
  return SizedBox(
    height: size.height / 4,
    width: size.width / 1.1,
    child: TextField(
      controller: cont,
      style: const TextStyle(
          fontSize: 18,
          color: Color.fromRGBO(252, 252, 252, 100),
          fontWeight: FontWeight.bold),
      decoration: const InputDecoration(
        hintText: 'Enter password',
        hintStyle:
        TextStyle(fontSize: 26, color: Color.fromRGBO(108, 173, 39, 50)),
        border: OutlineInputBorder(),
        enabledBorder: OutlineInputBorder(
          borderSide:
          BorderSide(width: 5, color: Color.fromRGBO(108, 173, 39, 100)),
        ),
        prefixIcon: Icon(
          Icons.mail,
          color: Color.fromRGBO(108, 173, 39, 100),
        ),
      ),
    ),
  );
}

Widget regButton(Size size) {
  return Container(
      height: size.height / 13,
      width: size.width / 1.1,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: const Color.fromRGBO(108, 173, 39, 100),
      ),
      alignment: Alignment.center,
      child: const Text("Create Account",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          )));
}

Widget logButton(Size size) {
  return Container(
      height: size.height / 13,
      width: size.width / 1.6,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: const Color.fromRGBO(108, 173, 39, 100),
      ),
      alignment: Alignment.center,
      child: const Text("Login",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          )));
}
class NavBar extends StatefulWidget {
  const NavBar({required Key key}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const DonatePage()),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const ContactPage()),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const AboutPage()),
        );
        break;
      default:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const DonatePage()),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color.fromRGBO(108, 173, 39, 100),
        currentIndex: _currentIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.monetization_on, color: Colors.black, size: 48),
            label: "Donate",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.phone, color: Colors.black, size: 48),
            label: "Contact",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.question_mark, color: Colors.black, size: 48),
            label: 'About',
          ),
        ],
      ),
    );
  }
}
