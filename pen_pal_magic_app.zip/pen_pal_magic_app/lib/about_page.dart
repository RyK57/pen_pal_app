import 'package:flutter/material.dart';

import 'login_screen.dart';

import 'donate_page.dart';
import 'contact_page.dart';

class AboutPage extends StatefulWidget {
  const AboutPage({Key? key}) : super(key: key);

  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      // resizeToAvoidBottomInset: false,
      // appBar: AppBar(
      //   title: const Text('Pen Pal Magic App'),
      //   backgroundColor: const Color.fromRGBO(
      //       108, 173, 39, 100), //top bar to display app title with color config
      // ),
        backgroundColor: const Color.fromRGBO(
            2, 71, 145, 100), //background color of app declared

        body: Padding(
          padding: const EdgeInsets.all(3.0),
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(children: <Widget>[
              SizedBox(
                  height: size.height / 8,
                  width: size.width / 1,
                  child: const Text('About us',
                      textAlign: TextAlign.center,
                      textScaleFactor: 2,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize:30,
                          fontWeight: FontWeight.bold
                      ))),
              SizedBox(
                  height: size.height / 2,
                  width: size.width / 1,
                  child: const Text('Inspired by a life-changing event, Murphy Charitable Foundation Uganda is a registered humanitarian non-profit organization established in 2018. We operate in Eastern Uganda and work with local communities in the Bukedea district and surrounding areas in North-eastern Uganda. After witnessing immense pain and heartache among vulnerable people who deal with the implications of poverty every day, we devised a series of projects with the objective of addressing the causes of poverty. At the Murphy Charitable Foundation Uganda, our goal is to support the rights and needs of people living below the poverty line in Ugandan communities to effectively mitigate the causes of poverty.',
                      textAlign: TextAlign.center,
                      textScaleFactor: 2,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize:10,
                          fontWeight: FontWeight.bold
                      ))
              ),
              SizedBox(
                  height: size.height / 4,
                  width: size.width / 1,
                  child: const Text('Mission Statement:We are committed to improving the quality of life for vulnerable groups of people in their communities by providing them with education, health care, clean water, and other basic needs. We also promote gender equality and empowerment to transform Ugandan communities and reduce poverty nationwide.',
                      textAlign: TextAlign.center,
                      textScaleFactor: 2,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize:10,
                          fontWeight: FontWeight.bold
                      ))
              ),
              SizedBox(
                  height: size.height / 6,
                  width: size.width / 1,
                  child: const Text('Vision:To enhance the livelihood of families in Ugandan communities, we provide them with basic needs to engender substantial living conditions. Additionally, we promote gender equality and empowerment, one of the fundamental issues that perpetuate poverty in Ugandan communities. Addressing these issues will help to alleviate poverty across Uganda.',
                      textAlign: TextAlign.center,
                      textScaleFactor: 2,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize:10,
                          fontWeight: FontWeight.bold

                      ))
              ),

              Container(
                  height: size.height / 11,
                  width: size.width,
                  alignment: Alignment.bottomCenter,
                  child: NavBar(key: UniqueKey())),]),
          ),
        ));
  }
}
class NavBar extends StatefulWidget {
  const NavBar({required Key key}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const DonatePage()),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const ContactPage()),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const AboutPage()),
        );
        break;
      default:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const DonatePage()),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color.fromRGBO(108, 173, 39, 100),
        currentIndex: _currentIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.monetization_on, color: Colors.black, size: 48),
            label: "Donate",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.phone, color: Colors.black, size: 48),
            label: "Contact",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.question_mark, color: Colors.black, size: 48),
            label: 'About',
          ),
        ],
      ),
    );
  }
}
