import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:pen_pal_magic_app/backendfuncs.dart';
import 'package:pen_pal_magic_app/three_screens.dart';
import 'package:pen_pal_magic_app/user_profile.dart';

import 'letters_screen.dart';

class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> with WidgetsBindingObserver{
  Map<String, dynamic>? userMap;
  bool isLoading = false;
  final TextEditingController _search = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    setStatus("Online");
  }

  void setStatus(String status) async {
    await _firestore.collection('users').doc(_auth.currentUser!.uid).update({
      "status": status,
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // online
      setStatus("Online");
    } else {
      // offline
      setStatus("Offline");
    }
  }

  String letterBoxId(String user1, String user2) {
    if (user1[0].toLowerCase().codeUnits[0] >
        user2.toLowerCase().codeUnits[0]) {
      return "$user1$user2";
    } else {
      return "$user2$user1";
    }
  }
  void onSearch() async {
    FirebaseFirestore _firestore = FirebaseFirestore.instance;
    setState(() {
      isLoading = true;
    });

    await _firestore
        .collection('users')
        .where("email", isEqualTo: _search.text)
        .get()
        .then((value) {
      setState(() {
        userMap = value.docs[0].data();
        isLoading = false;
      });
      print(userMap);
    });

  }


  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
        backgroundColor: Color.fromRGBO(2, 71, 145, 100),
        body: isLoading
            ? Center(
                child: Container(
                  height: size.height / 10,
                  width: size.height / 20,
                  child: CircularProgressIndicator(),
                ),
              )
            : SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                        height: size.height / 10,
                        width: size.width / 1,
                        child: const Text('Search Users',
                            textAlign: TextAlign.center,
                            textScaleFactor: 2,
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 30,
                                fontWeight: FontWeight.bold))),
                    Container(
                        height: size.height / 15,
                        width: size.width / 1,
                        alignment: Alignment.center,
                        child: Container(
                            height: size.height / 2,
                            width: size.width / 1,
                            child: TextField(
                                style: const TextStyle(
                                    fontSize: 18,
                                    color: Color.fromRGBO(252, 252, 252, 100),
                                    fontWeight: FontWeight.bold),
                                controller: _search,
                                decoration: InputDecoration(
                                    hintText: "Search users",
                                    hintStyle: TextStyle(
                                        fontSize: 26,
                                        color:
                                            Color.fromRGBO(108, 173, 39, 50)),
                                    border: OutlineInputBorder(),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          width: 5,
                                          color: Color.fromRGBO(
                                              108, 173, 39, 100)),
                                    ))))),
                    SizedBox(
                      height: size.height / 40,
                    ),
                    ElevatedButton(onPressed: onSearch, child: Text("Search")),
                    SizedBox(
                      height: size.height / 75,
                    ),
                    userMap != null
                        ? ListTile(
                            onTap: () {
                              String boxId = letterBoxId(
                                  _auth.currentUser!.displayName!,
                                  userMap!['email']);

                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (_) => LettersScreen(
                                      letterBoxId: boxId,
                                      userMap: userMap!)));
                            },
                            leading:
                                Icon(Icons.account_box, color: Colors.white),
                            title: Text(
                              userMap!['email'],
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            trailing: Icon(Icons.chat, color: Colors.white),
                          ):
                    SizedBox(
                      height: size.height / 30,
                      width: size.width / 5, // increased width
                    ),
            ElevatedButton(
              onPressed: () {},
              child: Text('Recommended'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color.fromRGBO(108, 173, 39, 100), // specified color
              ),
            ),
                    SizedBox(
                      height: size.height / 65,
                    ),
                    userMap != null
                        ? ListTile(
                      leading:
                      Icon(Icons.account_box, color: Colors.white),
                      title: Text(
                        'user3@gmail.com',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      trailing: Icon(Icons.chat, color: Colors.white),
                    ):
                    SizedBox(
                      height: size.height / 65,
                    ),
                    userMap != null
                        ? ListTile(
                      leading:
                      Icon(Icons.account_box, color: Colors.white),
                      title: Text(
                        'valed51@gmail.com',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      trailing: Icon(Icons.chat, color: Colors.white),
                    ):
                    SizedBox(
                      height: size.height / 65,
                    ),
                    userMap != null
                        ? ListTile(
                      leading:
                      Icon(Icons.account_box, color: Colors.white),
                      title: Text(
                        'broski69@gmail.com',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      trailing: Icon(Icons.chat, color: Colors.white),
                    ):
                    SizedBox(
                      height: size.height / 65,
                    ),
                    userMap != null
                        ? ListTile(
                      leading:
                      Icon(Icons.account_box, color: Colors.white),
                      title: Text(
                        'amelia31@gmail.com',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      trailing: Icon(Icons.chat, color: Colors.white),
                    ):
                    SizedBox(
                      height: size.height / 65,
                    ),
                    userMap != null
                        ? ListTile(
                      leading:
                      Icon(Icons.account_box, color: Colors.white),
                      title: Text(
                        'alexhunt@gmail.com',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      trailing: Icon(Icons.chat, color: Colors.white),

                    ):
                    SizedBox(
                      height: size.height / 50,
                    ),
                    ElevatedButton(onPressed: onSearch, child: Text("Show more")),
                    Container(
                        height: size.height / 9,
                        width: size.width,
                        alignment: Alignment.bottomCenter,
                        child: NavBar(key: UniqueKey())),
                  ],
                ),
              ));
  }
}

class NavBar extends StatefulWidget {
  const NavBar({required Key key}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => UserProfile()),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => SearchScreen()),
        );
        break;

      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ThreeScreens()),
        );
        break;
      default:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => UserProfile()),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(),
        bottomNavigationBar: Container(
            alignment: Alignment.bottomCenter,
            child: BottomNavigationBar(
              backgroundColor: const Color.fromRGBO(108, 173, 39, 100),
              currentIndex: _currentIndex,
              onTap: _onItemTapped,
              items: const [
                BottomNavigationBarItem(
                  icon: Icon(Icons.account_box_sharp,
                      color: Colors.black, size: 48),
                  label: "Profile",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.search_sharp, color: Colors.black, size: 48),
                  label: "Search",
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.info, color: Colors.black, size: 48),
                  label: 'App info',
                ),
              ],
            )));
  }
}
