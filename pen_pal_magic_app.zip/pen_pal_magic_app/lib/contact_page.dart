import 'package:flutter/material.dart';

import 'login_screen.dart';

import 'about_page.dart';
import 'donate_page.dart';

class ContactPage extends StatefulWidget {
  const ContactPage({Key? key}) : super(key: key);

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
        // resizeToAvoidBottomInset: false,
        // appBar: AppBar(
        //   title: const Text('Pen Pal Magic App'),
        //   backgroundColor: const Color.fromRGBO(
        //       108, 173, 39, 100), //top bar to display app title with color config
        // ),
        backgroundColor: const Color.fromRGBO(
            2, 71, 145, 100), //background color of app declared

        body: Padding(
          padding: const EdgeInsets.all(3.0),
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(children: <Widget>[
              SizedBox(
                  height: size.height / 9,
                  width: size.width / 1,
                  child: const Text('Contact',
                      textAlign: TextAlign.center,
                      textScaleFactor: 2,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.bold))),
            SizedBox(
              height: size.height / 14,
              width: size.width / 0.3,
              child: chromeImg(size),
          ),
              SizedBox(
                  height: size.height / 15,
                  width: size.width / 1,
                  child: const Text('murphycharity.org',
                      textAlign: TextAlign.left,
                      textScaleFactor: 2,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold))),
              SizedBox(
                height: size.height / 14,
                width: size.width / 0.3,
                child: instaImg(size),
              ),
              SizedBox(
                  height: size.height / 15,
                  width: size.width / 1,
                  child: const Text('murphycharitablefoundation',
                      textAlign: TextAlign.left,
                      textScaleFactor: 2,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold))),
              SizedBox(
                height: size.height / 14,
                width: size.width / 0.3,
                child: gmailImg(size),
              ),
              SizedBox(
                  height: size.height / 15,
                  width: size.width / 1,
                  child: const Text('murphycharity.info@gmail.com',
                      textAlign: TextAlign.left,
                      textScaleFactor: 2,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold))),
              SizedBox(
                height: size.height / 14,
                width: size.width / 0.3,
                child: phoneImg(size),
              ),
              SizedBox(
                  height: size.height / 15,
                  width: size.width / 1,
                  child: const Text('+256-771-983900',
                      textAlign: TextAlign.left,
                      textScaleFactor: 2,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold))),
              SizedBox(
                height: size.height / 14,
                width: size.width / 0.3,
                child: linkedinImg(size),
              ),
                  SizedBox(
                      height: size.height / 7,
                      width: size.width / 1,
                      child: const Text('MURPHY CHARITABLE FOUNDATION UGANDA',
                          textAlign: TextAlign.left,
                          textScaleFactor: 2,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 08,
                              fontWeight: FontWeight.bold))),
              Container(
                  height: size.height / 9,
                  width: size.width,
                  alignment: Alignment.bottomCenter,
                  child: NavBar(key: UniqueKey())),
            ]),
          ),
        ));
  }
}


Widget chromeImg(Size size) {
  return SizedBox(
    height: size.height / 6,
    width: size.width / 3,
    child: Image.asset('assets/images/chrome.png',
      alignment: Alignment.centerLeft,
  ));
}

Widget instaImg(Size size) {
  return SizedBox(
    height: size.height / 4,
    width: size.width / 1.1,
    child: Image.asset('assets/images/insta.png',
      alignment: Alignment.centerLeft,
  ));
}

Widget gmailImg(Size size) {
  return SizedBox(
    height: size.height / 4,
    width: size.width / 1.1,
    child: Image.asset('assets/images/gmail.png',
      alignment: Alignment.centerLeft,

  ));
}

Widget phoneImg(Size size) {
  return SizedBox(
    height: size.height / 6,
    width: size.width / 1.1,
    child: Image.asset('assets/images/phone.png',
      alignment: Alignment.centerLeft,

    ));
}

Widget linkedinImg(Size size) {
  return SizedBox(
    height: size.height / 4,
    width: size.width / 1.1,
    child: Image.asset('assets/images/linkedin.png',
      alignment: Alignment.centerLeft,

  ));
}
class NavBar extends StatefulWidget {
  const NavBar({required Key key}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const DonatePage()),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const ContactPage()),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const AboutPage()),
        );
        break;
      default:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const DonatePage()),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color.fromRGBO(108, 173, 39, 100),
        currentIndex: _currentIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.monetization_on, color: Colors.black, size: 48),
            label: "Donate",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.phone, color: Colors.black, size: 48),
            label: "Contact",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.question_mark, color: Colors.black, size: 48),
            label: 'About',
          ),
        ],
      ),
    );
  }
}
