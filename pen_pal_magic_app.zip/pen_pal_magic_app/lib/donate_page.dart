import 'package:flutter/material.dart';

import 'login_screen.dart';

import 'about_page.dart';
import 'contact_page.dart';

class DonatePage extends StatefulWidget {
  const DonatePage({Key? key}) : super(key: key);

  @override
  State<DonatePage> createState() => _DonatePageState();
}

class _DonatePageState extends State<DonatePage> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      // resizeToAvoidBottomInset: false,
      // appBar: AppBar(
      //   title: const Text('Pen Pal Magic App'),
      //   backgroundColor: const Color.fromRGBO(
      //       108, 173, 39, 100), //top bar to display app title with color config
      // ),
      backgroundColor: const Color.fromRGBO(
          2, 71, 145, 100), //background color of app declared

      body: Padding(
        padding: const EdgeInsets.all(3.0),
        child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(children: <Widget>[
              SizedBox(
                height: size.height / 4,
                width: size.width / 1,
                child: const Text('Donate',
                  textAlign: TextAlign.center,
                  textScaleFactor: 2,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize:30,
                    fontWeight: FontWeight.bold
              ))),
          SizedBox(
              height: size.height / 12,
              width: size.width / 1,
              child: const Text('Copy below link for donation through PayPal',
                  textAlign: TextAlign.center,
                  textScaleFactor: 2,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize:10,
                      fontWeight: FontWeight.bold
                  ))
          ),
          SizedBox(
              height: size.height / 6,
              width: size.width / 1,
              child: const Text('https://www.paypal.com/donate/?hosted_button_id=5AFEFHRYLY558',
                  textAlign: TextAlign.center,
                  textScaleFactor: 2,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize:10,
                      fontWeight: FontWeight.bold
                  ))
          ),
              SizedBox(
                  height: size.height / 17,
                  width: size.width / 1,
                  child: const Text('Financial Details',
                      textAlign: TextAlign.center,
                      textScaleFactor: 2,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize:10,
                          fontWeight: FontWeight.bold

                      ))
              ),
            SizedBox(
            height: size.height / 3,
            width: size.width / 1,
            child: const Text('1, Account Name : Murphy charitable foundation Uganda,\n 2) Account Number: 01113657970966,\n 3)Bank Name: Dfcu Bank Uganda, \n 4)Swift code: DFCUUGKA.',
                textAlign: TextAlign.center,
                textScaleFactor: 2,
                style: TextStyle(
                    color: Colors.white,
                    fontSize:10,
                    fontWeight: FontWeight.bold
                ))
            ),
              Container(
                  height: size.height / 11,
                  width: size.width,
                  alignment: Alignment.bottomCenter,
                  child: NavBar(key: UniqueKey())),]),
      ),
    ));
  }
}

class NavBar extends StatefulWidget {
  const NavBar({required Key key}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const DonatePage()),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const ContactPage()),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const AboutPage()),
        );
        break;
      default:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const DonatePage()),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color.fromRGBO(108, 173, 39, 100),
        currentIndex: _currentIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.monetization_on, color: Colors.black, size: 48),
            label: "Donate",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.phone, color: Colors.black, size: 48),
            label: "Contact",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.question_mark, color: Colors.black, size: 48),
            label: 'About',
          ),
        ],
      ),
    );
  }
}
